/************************************
*VR489009
*Corato Francesco
*
*VR488626
*Sinico Enrico
*
*2024-09-09
*************************************/
#ifndef Segnali
#define Segnali
int ModificaFunzioneSegnale(int sig, void * Function);
#endif